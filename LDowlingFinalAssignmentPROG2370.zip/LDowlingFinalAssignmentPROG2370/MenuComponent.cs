﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace LDowlingFinalAssignmentPROG2370
{
    class MenuComponent : DrawableGameComponent
    {
        private SpriteBatch spriteBatch;
        private SpriteFont regularFont, hiLightFont;
        private List<string> menuItems;
        private int selectedIndex = 0;
        private Vector2 position;
        private Color regularColor = Color.White;
        private Color hiLightColor = Color.Orange;
        private KeyboardState oldState;
        private Texture2D background;

    public MenuComponent(Game game,
        SpriteBatch spriteBatch,
        SpriteFont regularFont,
        SpriteFont hiLightFont,
        string[] menus) : base(game)
        {
            Game1 g = (Game1)game;
            this.spriteBatch = g.spriteBatch;
            this.regularFont = regularFont;
            this.hiLightFont = hiLightFont;
            menuItems = menus.ToList();
            this.position = new Vector2(Shared.stage.X/ 2, Shared.stage.Y / 2);

            background = g.Content.Load<Texture2D>("Images/actionscene");
        }

        public int SelectedIndex { get => selectedIndex; set => selectedIndex = value; }

        public override void Draw(GameTime gameTime)
        {
            Vector2 tempPos = position;
            spriteBatch.Begin();
            spriteBatch.Draw(background, new Rectangle(0, 0, 1500, 900), Color.White);

            for (int i = 0; i < menuItems.Count; i++)
            {
                //tempPos.Y += 30;
                if (selectedIndex == i)
                {
                    spriteBatch.DrawString(hiLightFont, menuItems[i], tempPos, hiLightColor);
                    tempPos.Y += hiLightFont.LineSpacing;
                }
                else
                {
                    spriteBatch.DrawString(regularFont, menuItems[i], tempPos, regularColor);
                    tempPos.Y += regularFont.LineSpacing;
                }
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();
            MouseState ms = Mouse.GetState();
            if (ks.IsKeyDown(Keys.Down) && oldState.IsKeyUp(Keys.Down))
            {
                selectedIndex++;
                if (selectedIndex == menuItems.Count)
                {
                    selectedIndex = 0;
                }

            }
            if (ks.IsKeyDown(Keys.Up) && oldState.IsKeyUp(Keys.Up))
            {
                selectedIndex--;
                if (selectedIndex < 0)
                {
                    selectedIndex = menuItems.Count - 1;
                }

            }
            oldState = ks;
            base.Update(gameTime);
        }
    }
}
