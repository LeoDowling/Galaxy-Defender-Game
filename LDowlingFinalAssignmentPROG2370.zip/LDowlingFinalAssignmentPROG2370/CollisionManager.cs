﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace LDowlingFinalAssignmentPROG2370
{
    class CollisionManager : DrawableGameComponent
    {
        private BasicBullet basicBullet;
        private YourShip yourship;
        private EnemyShip enemyShip;
        private SoundEffect explosionSound;
        Explosion explosion;


        public CollisionManager(Game game,
            BasicBullet basicBullet,
            YourShip yourship,
            EnemyShip enemyShip,
            SoundEffect explosionSound,
            Explosion explosion): base(game)
        {
            this.basicBullet = basicBullet;
            this.yourship = yourship;
            this.enemyShip = enemyShip;
            this.explosionSound = explosionSound;
            this.explosion = explosion;
        }

        public override void Update(GameTime gameTime)
        {
            //Rectangle basicBulletRect = basicBullet.getBound();
            //Rectangle yourShipRect = yourship.getBound();
            //Rectangle enemyShipRect = enemyShip.getBound();


            //if (basicBulletRect.Intersects(enemyShipRect))
            //{

            //    enemyShip.Visible = false;
            //    basicBullet.Visible = false;

            //}
            //if (enemyShipRect.Intersects(yourShipRect))
            //{
            //    enemyShip.Visible = false;
            //    life--;
            //}
            base.Update(gameTime);
        }
    }
}
