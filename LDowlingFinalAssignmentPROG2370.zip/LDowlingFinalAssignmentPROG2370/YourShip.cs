﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace LDowlingFinalAssignmentPROG2370
{
    /// <summary>
    /// generating constructor and drawing the image for the users ship
    /// </summary>
    public class YourShip : DrawableGameComponent
    {
        private SpriteBatch spriteBatch;
        private Texture2D tex;
        public float bulletDelay;
        private Vector2 position;
        private Vector2 Yspeed;
        private Vector2 Xspeed;
        public List<BasicBullet> bullets;
        public BasicBullet bullet;
        public Texture2D bulletTex;

        private GameScene actionScene;

        BasicBullet b;

        public Vector2 Position { get => position; set => position = value; }

        public YourShip (Game game, 
            SpriteBatch spriteBatch,
            Texture2D tex,
            Texture2D bulletTex,
            GameScene actionScene) : base(game)
        {
            bullets = new List<BasicBullet>();
            this.spriteBatch = spriteBatch;
            this.tex = tex;
            position = new Vector2(0,250);
            Yspeed = new Vector2(0, 10);
            Xspeed = new Vector2(10, 0);
            this.bulletTex = bulletTex;
            this.actionScene = actionScene;
        }

        public YourShip(Game game): base(game)
        {

        }
        
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(tex, position, Color.White);
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();
            if (ks.IsKeyDown(Keys.Up) || ks.IsKeyDown(Keys.W))
            {
                position -= Yspeed;
            }
            if (ks.IsKeyDown(Keys.Down) || ks.IsKeyDown(Keys.S))
            {
                position += Yspeed;
            }
            if (ks.IsKeyDown(Keys.Right) || ks.IsKeyDown(Keys.D))
            {
                position += Xspeed;

            }
            if (ks.IsKeyDown(Keys.Left) || ks.IsKeyDown(Keys.A))
            {
                position -= Xspeed;
            }
            if (position.Y < 0)
            {
                position.Y = 0;
            }
            if (position.X < 0)
            {
                position.X = 0;
            }
            if (position.X + tex.Width > Shared.stage.X)
            {
                position.X = Shared.stage.X - tex.Width;
            }
            if (position.Y + tex.Height > Shared.stage.Y)
            {
                position.Y = Shared.stage.Y - tex.Height;
            }
            //if (ks.IsKeyDown(Keys.Space))
            //{
            //    //b = new BasicBullet(Game, spriteBatch, bulletTex);
            //    //b.Position = this.Position;
            //    //actionScene.Components.Add(b);
            //    //bulletFired = true;
            //    //if (b.position.X > 1200)
            //    //{

            //    //}

            //}
            

            base.Update(gameTime);
        }
        public Rectangle getBound()
        {
            return new Rectangle((int)position.X, (int)position.Y, tex.Width, tex.Height);
        }
    }
}
