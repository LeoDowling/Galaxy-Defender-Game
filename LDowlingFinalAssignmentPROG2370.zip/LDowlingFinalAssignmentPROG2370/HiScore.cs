﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace LDowlingFinalAssignmentPROG2370
{
    class HiScore: DrawableGameComponent
    {
        private SpriteBatch spriteBatch;
        private SpriteFont font;
        private Vector2 position;
        private string message;
        private Color color;
        public string Message { get => message; set => message = value; }
        public Vector2 Position { get => position; set => position = value; }
        private GameScene actionScene;

        public HiScore(Game game,SpriteBatch spriteBatch, SpriteFont font, Vector2 position, string message, Color color, GameScene actionScene): base(game)
        {
            this.spriteBatch = spriteBatch;
            this.font = font;
            this.position = position;
            this.message = message;
            this.color = color;
            this.actionScene = actionScene;
        }

        public override void Update(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.DrawString( font, message, position, color);
            spriteBatch.End();
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }
    }
}
