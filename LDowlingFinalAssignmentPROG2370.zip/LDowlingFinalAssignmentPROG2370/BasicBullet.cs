﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace LDowlingFinalAssignmentPROG2370
{
    public class BasicBullet : DrawableGameComponent
    {
        
        private SpriteBatch spriteBatch;
        private Texture2D bulletTex;
        private Vector2 position;
        private Vector2 Xspeed;
        private List<BasicBullet> bullets;

        private GameScene actionScene;
        public bool isVisible = true;
        // private YourShip yourShip;

        public Vector2 Position { get => position; set => position = value; }

        public BasicBullet(Game game,
            SpriteBatch spriteBatch,
            Texture2D bulletTex,
            GameScene actionScene) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.bulletTex = bulletTex;
           // this.yourShip = yourShip;
            position = new Vector2(0, 0);
            Xspeed = new Vector2(10, 0);
            this.actionScene = actionScene;
            
        }
        public BasicBullet(Game game) : base(game)
        {

        }


        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
          //  if (bulletFired == true)
//{

                spriteBatch.Draw(bulletTex, position, Color.White);

          //  }
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {


            position += Xspeed;

            base.Update(gameTime);
        }
        public Rectangle getBound()
        {
            return new Rectangle((int)position.X, (int)position.Y, bulletTex.Width, bulletTex.Height);
        }
    }
}
