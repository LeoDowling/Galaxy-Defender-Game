﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace LDowlingFinalAssignmentPROG2370
{
    /// <summary>
    /// performs all actions that occur when the user is playing the game
    /// </summary>
    public class ActionScene : GameScene
    {
        //enums for the game state
        public enum State
        {
            Menu,
            Playing,
            GameOver
        }
        //All Variables
        private SpriteBatch spriteBatch;
        private YourShip yourShip;
        private BasicBullet basicBullet;
        private EnemyShip enemyShip;
        private BigEnemyShip bigEnemyShip;
        private Texture2D background;
        private Texture2D gameOverBackground;
        private CollisionManager cm;
        private SpriteFont font;
        private HiScore hiScore;
        Texture2D basicBulletTex;
        Texture2D explosionTex;
        Texture2D bigEnemyTex;
        KeyboardState oldState;
        Game1 g;
        List<EnemyShip> enemies = new List<EnemyShip>();
        List<BigEnemyShip> bigEnemies = new List<BigEnemyShip>();
        List<BasicBullet> bullets = new List<BasicBullet>();
        Random rand = new Random();
        Random rand2 = new Random();
        float smallEnemySpawn = -1;
        float bigEnemySpawn = -1;
        float gameOverDelay = 2;
        Texture2D enemyTex;
        SoundEffect bulletSound;
        SoundEffect explosionSound;
        SoundEffect gameOverSound;
        private int life = 3;

        Explosion explosion;
        private int score = 0;

        State gameState = State.Playing;
        


        //constructor for action scene
        public ActionScene(Game game) : base(game)
        {
             g = (Game1)game;
            //loading content for all game entities
            this.spriteBatch = g.spriteBatch;
            Texture2D yourShipTex = g.Content.Load<Texture2D>("Images/bgbattleship");
            
            basicBulletTex = g.Content.Load<Texture2D>("Images/BasicBullet");
            enemyTex = g.Content.Load<Texture2D>("Images/smallfreighterspr");
            explosionTex = g.Content.Load<Texture2D>("Images/Explosion");
            bigEnemyTex = g.Content.Load<Texture2D>("Images/BossShip");
            gameOverBackground = g.Content.Load<Texture2D>("Images/gameOverScene");

           
            yourShip = new YourShip(g, spriteBatch, yourShipTex, basicBulletTex, this);
            enemyShip = new EnemyShip(g, spriteBatch, enemyTex, new Vector2(1500,900), this);
            bigEnemyShip = new BigEnemyShip(g, spriteBatch, bigEnemyTex, new Vector2(1500, 900), this, life);
            basicBullet = new BasicBullet(g, spriteBatch, basicBulletTex, this);
            explosion = new Explosion(g, spriteBatch, explosionTex, enemyShip.Position, 2);
            background = g.Content.Load<Texture2D>("Images/actionsceneBackground");
            explosionSound = g.Content.Load<SoundEffect>("Sounds/253169__suntemple__retro-game-sfx-explosion");
            bulletSound = g.Content.Load<SoundEffect>("Sounds/344310__musiclegends__laser-shoot");
            gameOverSound = g.Content.Load <SoundEffect>("Sounds/382310__myfox14__game-over-arcade");

            //this.Components.Add(basicBullet);
            this.Components.Add(yourShip);
            CollisionManager cm = new CollisionManager(g, basicBullet, yourShip, enemyShip, explosionSound, explosion);
            this.Components.Add(cm);
            font = g.Content.Load<SpriteFont>("Fonts/HiLightFont");
            Vector2 strPosition = new Vector2(0, 0);
            string message = "";
            hiScore = new HiScore(g, spriteBatch, font, strPosition,
                message, Color.Orange, this);
            string gameOverMsg = "";
            
            


        }
        public override void Draw(GameTime gameTime)
        {
            //drawing image based on game state
            switch(gameState)
            {
                case State.Playing:
                    {
                        spriteBatch.Begin();
                        spriteBatch.Draw(background, new Rectangle(0, 0, 1500, 900), Color.White);
                        spriteBatch.DrawString(font, hiScore.Message, hiScore.Position, Color.Orange);
                        spriteBatch.End();
                        break;
                    }
                case State.Menu:
                    {
                        break;
                    }
                case State.GameOver:
                    {
                        spriteBatch.Begin();
                        spriteBatch.Draw(gameOverBackground, new Rectangle(0, 0, 1500, 900), Color.White);
                        spriteBatch.DrawString(font, hiScore.Message, hiScore.Position, Color.Orange);
                        spriteBatch.End();
                        break;
                    }
            }
            
            base.Draw(gameTime);
        }
        
        public override void Update(GameTime gameTime)
        {
            
            //based on game state, do actions
            switch(gameState)
            {
                //fire bullet when playing
                case State.Playing:
                    {
                        KeyboardState ks = Keyboard.GetState();
                        if (ks.IsKeyDown(Keys.Space) && oldState.IsKeyUp(Keys.Space))
                        {


                            basicBullet = new BasicBullet(g, spriteBatch, basicBulletTex, this);
                            basicBullet.Position = yourShip.Position;
                            bullets.Add(basicBullet);
                            bulletSound.Play();
                            this.Components.Add(basicBullet);

                        }

                        oldState = ks;
                        //spawn small enemies
                        int randY = rand.Next(100, 400);
                        int bigRandY = rand2.Next(0, 600);
                        if (smallEnemySpawn >= 1)
                        {
                            smallEnemySpawn = 0;
                            if (enemies.Count() < 1)
                            {
                                enemyShip = new EnemyShip(g, spriteBatch, enemyTex, new Vector2(1500, randY), this);
                                enemies.Add(enemyShip);

                                this.Components.Add(enemyShip);
                            }
                        }
                        for (int i = 0; i < enemies.Count; i++)
                        {
                            if (!enemies[i].isVisible)
                            {
                                enemies.RemoveAt(i);
                                i--;
                            }
                        }
                        //spawn big enemies
                        if (bigEnemySpawn >= 1)
                        {
                            bigEnemySpawn = 0;
                            if (bigEnemies.Count() < 1)
                            {
                                bigEnemyShip = new BigEnemyShip(g, spriteBatch, bigEnemyTex, new Vector2(1500, bigRandY), this, life);
                                bigEnemies.Add(bigEnemyShip);

                                this.Components.Add(bigEnemyShip);
                            }
                        }
                        for (int i = 0; i < bigEnemies.Count; i++)
                        {
                            if (!bigEnemies[i].isVisible)
                            {
                                bigEnemies.RemoveAt(i);
                                i--;
                            }
                        }
                        //spawn based on gametime
                        smallEnemySpawn += (float)gameTime.ElapsedGameTime.TotalSeconds;
                        bigEnemySpawn += (float)gameTime.ElapsedGameTime.TotalSeconds;
                        //
                        Rectangle basicBulletRect = basicBullet.getBound();
                        Rectangle yourShipRect = yourShip.getBound();
                        Rectangle enemyShipRect = enemyShip.getBound();
                        Rectangle bigEnemyRect = bigEnemyShip.getBound();

                        if (enemyShipRect.Intersects(basicBulletRect))
                        {

                            enemyShip.Visible = false;
                            for (int i = 0; i < enemies.Count; i++)
                            {
                                if (enemies[i].isVisible)
                                {
                                    enemies.RemoveAt(i);
                                    i--;
                                    score = score + 500;
                                }
                            }
                            basicBullet.Visible = false;
                            basicBullet.Enabled = false;
                            for (int i = 0; i < bullets.Count; i++)
                            {
                                if (bullets[i].isVisible)
                                {
                                    bullets.RemoveAt(i);
                                    i--;
                                }
                            }
                            explosion = new Explosion(g, spriteBatch, explosionTex, enemyShip.Position, 2);
                            this.Components.Add(explosion);
                            explosion.Visible = true;
                            explosion.Enabled = true;
                            explosionSound.Play();

                        }
                        if (enemyShipRect.Intersects(yourShipRect))
                        {
                            gameOverSound.Play();
                            enemyShip.Visible = false;
                            yourShip.Visible = false;
                            gameState = State.GameOver;
                            for (int i = 0; i < enemies.Count; i++)
                            {
                                if (enemies[i].isVisible)
                                {
                                    enemies.RemoveAt(i);
                                    i--;
                                }
                            }
                            explosion = new Explosion(g, spriteBatch, explosionTex, enemyShip.Position, 2);
                            this.Components.Add(explosion);
                            explosion.Visible = true;
                            explosion.Enabled = true;
                            explosionSound.Play();
                            
                            ;

                        }
                        if (bigEnemyRect.Intersects(basicBulletRect))
                        {

                            
                            
                                bigEnemyShip.Visible = false;
                                for (int i = 0; i < bigEnemies.Count; i++)
                                {
                                    if (bigEnemies[i].isVisible)
                                    {
                                        bigEnemies.RemoveAt(i);
                                        i--;
                                        score = score + 1000;
                                    }
                                }
                                basicBullet.Visible = false;
                                for (int i = 0; i < bullets.Count; i++)
                                {
                                    if (bullets[i].isVisible)
                                    {
                                        bullets.RemoveAt(i);
                                        i--;
                                    }
                                }
                            
                                basicBullet.Visible = false;
                                for (int i = 0; i < bullets.Count; i++)
                                {
                                    if (bullets[i].isVisible)
                                    {
                                        bullets.RemoveAt(i);
                                        i--;
                                    }
                                }
                            

                            explosion = new Explosion(g, spriteBatch, explosionTex, bigEnemyShip.Position, 2);
                            this.Components.Add(explosion);
                            explosion.Visible = true;
                            explosion.Enabled = true;
                            explosionSound.Play();

                        }
                        if (bigEnemyRect.Intersects(yourShipRect))
                        {
                            gameOverSound.Play();
                            bigEnemyShip.Visible = false;
                            yourShip.Visible = false;
                            gameState = State.GameOver;
                            for (int i = 0; i < bigEnemies.Count; i++)
                            {
                                if (bigEnemies[i].isVisible)
                                {
                                    bigEnemies.RemoveAt(i);
                                    i--;
                                }
                            }
                            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
                            gameOverDelay -= elapsed;
                            if (gameOverDelay < 0)
                            {



                                //Reset Timer
                            }
                            explosion = new Explosion(g, spriteBatch, explosionTex, bigEnemyShip.Position, 2);
                            this.Components.Add(explosion);
                            explosion.Visible = true;
                            explosion.Enabled = true;
                            explosionSound.Play();
                            
                            life--;

                        }

                        string msg = "HiScore: " + score;
                        hiScore.Message = msg;
                        Vector2 dimension = font.MeasureString(msg);
                        hiScore.Position = new Vector2(1100, 830);
                        this.Components.Add(hiScore);

                        base.Update(gameTime);
                        break;
                    }
                case State.Menu:
                    {
                        KeyboardState ks = Keyboard.GetState();
                        if(ks.IsKeyDown(Keys.Enter))
                        {
                            gameState = State.Playing;
                        }
                        break;
                    }
                case State.GameOver:
                    {
                        KeyboardState ks = Keyboard.GetState();
                        string gameOverMsg = "Your Score was: " + score;
                        hiScore.Message = gameOverMsg;
                        Vector2 dimension = font.MeasureString(gameOverMsg);
                        hiScore.Position = new Vector2(500, 750);
                        this.Components.Add(hiScore);
                        if(ks.IsKeyDown(Keys.Enter))
                        {
                            yourShip.Visible = true;
                            score = 0;
                            yourShip.Position = new Vector2(0, 250);
                            gameState = State.Playing;
                        }

                        
                        if(ks.IsKeyDown(Keys.Escape) && oldState.IsKeyUp(Keys.Escape))
                        {

                            gameState = State.Playing;
                        }
                        oldState = ks;


                        break;
                    }

            }

            
        }
        
            

        

    }
}
