﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace LDowlingFinalAssignmentPROG2370
{
    public class EnemyShip : DrawableGameComponent
    {
        public SpriteBatch spriteBatch;
        private Texture2D tex;
        private Vector2 position;
        private Vector2 speed;
        private GameScene actionScene;
        List<EnemyShip> enemies = new List<EnemyShip>();

        public bool isVisible = true;

        Random random = new Random();
        public int randX, randY;

        
        public Vector2 Speed { get => speed; set => speed = value; }
        public Vector2 Position { get => position; set => position = value; }
        public Texture2D Tex { get => tex; set => tex = value; }

        public EnemyShip(Game game, 
            SpriteBatch spriteBatch, 
            Texture2D tex,
            Vector2 position,
            GameScene actionScene) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.tex = tex;
            this.position = position;
            
            randY = random.Next(-4, 4);
            randX = random.Next(-4, -1);

            speed = new Vector2(randX, randY);
            this.actionScene = actionScene;
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(tex, position, Color.White);
            spriteBatch.End();
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            position += speed;

            if(position.Y <= 0 || position.Y >= 900)
            {
                speed.Y = -speed.Y;
            }
            if(position.X < 0 - tex.Width)
            {
                isVisible = false;
            }
            base.Update(gameTime);
        }
        public List<Rectangle> boundList = new List<Rectangle>();
        
        public Rectangle getBound()
        {
            
                return new Rectangle ((int)position.X, (int)position.Y, tex.Width, tex.Height);
           
        }
        
        
    }
}
