﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace LDowlingFinalAssignmentPROG2370
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        public enum State
        {
            Menu,
            Playing, 
            GameOver,
            Help
        }
        GraphicsDeviceManager graphics;
        public SpriteBatch spriteBatch;
        public Vector2 spritePosition;
        //Declare all scene references
        private StartScene startScene;
        //actionScene
        private ActionScene actionScene;
        private GameOverScene gameOverScene;
        private CreditScene creditScene;
        List<BasicBullet> bullets = new List<BasicBullet>();
        //helpScene
        private HelpScene helpScene;
        List<EnemyShip> enemies = new List<EnemyShip>();
        Random rand = new Random();
        float spawn = 0;

        State gameState = State.Menu;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 1500;
            graphics.PreferredBackBufferHeight = 900;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            Shared.stage = new Vector2(graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            Texture2D tex = this.Content.Load<Texture2D>("Images/actionscene");
 
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            //Create StartScene instance
            startScene = new StartScene(this);
            this.Components.Add(startScene);
            startScene.Show();

            //Create other scenes instances
            actionScene = new ActionScene(this);
            this.Components.Add(actionScene);

            helpScene = new HelpScene(this);
            this.Components.Add(helpScene);

            gameOverScene = new GameOverScene(this);
            this.Components.Add(gameOverScene);

            creditScene = new CreditScene(this);
            this.Components.Add(creditScene);

            // TODO: use this.Content to load your game content here
            SoundEffect explosion = this.Content.Load<SoundEffect>("Sounds/253169__suntemple__retro-game-sfx-explosion");
            SoundEffect bulletSound = this.Content.Load<SoundEffect>("Sounds/362457__jalastram__shooting-sounds-001");
            Song song = this.Content.Load<Song>("Sounds/ZeroRanger - Unstopping (wintro)");
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(song);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            int selectedIndex = 0;

            KeyboardState ks = Keyboard.GetState();
            if (startScene.Enabled)
            {
                selectedIndex = startScene.Menu.SelectedIndex;
                if (selectedIndex == 0 && ks.IsKeyDown(Keys.Enter))
                {
                    actionScene.Show();
                    startScene.Hide();
                    
                    gameState = State.Playing;
                }
                else if (selectedIndex == 1 && ks.IsKeyDown(Keys.Enter))
                {
                    helpScene.Show();
                    startScene.Hide();
                    gameState = State.Help;
                }
                else if (selectedIndex == 2 && ks.IsKeyDown(Keys.Enter))
                {
                    creditScene.Show();
                    startScene.Hide();
                }
                

                else if (selectedIndex == 3 && ks.IsKeyDown(Keys.Enter))
                {
                    Exit();
                }
            }
            if (actionScene.Enabled)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {
                    startScene.Show();
                    actionScene.Hide();
                    actionScene.Initialize();
                    gameState = State.Menu;
                }
            }
            if (helpScene.Enabled)
            {
                if (ks.IsKeyDown(Keys.Escape))
                {
                    startScene.Show();
                    helpScene.Hide();
                    gameState = State.Menu;
                }
            }
            if(gameOverScene.Enabled)
            {
                startScene.Show();
                actionScene.Hide();
                if ( gameOverScene.Enabled && ks.IsKeyDown(Keys.Escape))
                {
                    
                    gameState = State.Playing;
                }
            }
            if(ks.IsKeyDown(Keys.Escape))
            {
                startScene.Show();
                creditScene.Hide();
            }
            


            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        

        
            

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
